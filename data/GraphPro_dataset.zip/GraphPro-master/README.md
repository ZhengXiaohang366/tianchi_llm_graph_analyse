# GraphPro
This is the repository for GraphPro benchmark and LLM4Graph datasets.



The recommended python version is 3.10.14, and you can use the requirements.txt to install the python libraries for this project.



```bash
conda create --name graphpro python=3.10.14

pip install -r requirements.txt
```



The doc datasets are the recommended datasets of the organizing committee.



More will be released soon.
